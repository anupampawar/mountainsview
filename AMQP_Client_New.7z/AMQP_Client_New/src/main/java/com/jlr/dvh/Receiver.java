package com.jlr.dvh;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class Receiver {
  private static final Logger logger = LoggerFactory.getLogger(Receiver.class);
  //private CountDownLatch latch = new CountDownLatch(1);

 // @RabbitListener(queues = "pimaster.campaignstatus.sp")
  public void receiveMessage(String cs) {
    System.out.println("Received <<<<<  " + cs.toString() + ">>>>>");
    //latch.countDown();
  }
  
	/*
	 * public CountDownLatch getLatch() { return latch; }
	 */
}