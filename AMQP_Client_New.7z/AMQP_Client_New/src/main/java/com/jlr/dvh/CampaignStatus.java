package com.jlr.dvh;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CampaignStatus {

	String CampaignOrRepairID;
	String CampaignOption;
	String Vin;
	String RetailerID;
	String RetailerReference;
	String TechnicianID;
	String ClaimType;
	String Executor;
	String MileageAtTimeOfUpdate;
	String UnitOfMeasure;
	String DateOfChange;
	String JobCardNumber;
	List<String> DTCCode = new ArrayList<>();
	String MIL;
	
	public String getCampaignOrRepairID() {
		return CampaignOrRepairID;
	}
	public void setCampaignOrRepairID(String campaignOrRepairID) {
		CampaignOrRepairID = campaignOrRepairID;
	}
	public String getCampaignOption() {
		return CampaignOption;
	}
	public void setCampaignOption(String campaignOption) {
		CampaignOption = campaignOption;
	}
	public String getVin() {
		return Vin;
	}
	public void setVin(String vin) {
		Vin = vin;
	}
	public String getRetailerID() {
		return RetailerID;
	}
	public void setRetailerID(String retailerID) {
		RetailerID = retailerID;
	}
	public String getRetailerReference() {
		return RetailerReference;
	}
	public void setRetailerReference(String retailerReference) {
		RetailerReference = retailerReference;
	}
	public String getTechnicianID() {
		return TechnicianID;
	}
	public void setTechnicianID(String technicianID) {
		TechnicianID = technicianID;
	}
	public String getClaimType() {
		return ClaimType;
	}
	public void setClaimType(String claimType) {
		ClaimType = claimType;
	}
	public String getExecutor() {
		return Executor;
	}
	public void setExecutor(String executor) {
		Executor = executor;
	}
	public String getMileageAtTimeOfUpdate() {
		return MileageAtTimeOfUpdate;
	}
	public void setMileageAtTimeOfUpdate(String mileageAtTimeOfUpdate) {
		MileageAtTimeOfUpdate = mileageAtTimeOfUpdate;
	}
	public String getUnitOfMeasure() {
		return UnitOfMeasure;
	}
	public void setUnitOfMeasure(String unitOfMeasure) {
		UnitOfMeasure = unitOfMeasure;
	}
	public String getDateOfChange() {
		return DateOfChange;
	}
	public void setDateOfChange(String dateOfChange) {
		DateOfChange = dateOfChange;
	}
	public String getJobCardNumber() {
		return JobCardNumber;
	}
	public void setJobCardNumber(String jobCardNumber) {
		JobCardNumber = jobCardNumber;
	}
	public List<String> getDTCCode() {
		return DTCCode;
	}
	public void setDTCCode(List<String> dTCCode) {
		DTCCode = dTCCode;
	}
	public String getMIL() {
		return MIL;
	}
	public void setMIL(String mIL) {
		MIL = mIL;
	}
	
	@Override
	public String toString() {
		return "ReqObject [CampaignOrRepairID=" + CampaignOrRepairID + ", CampaignOption=" + CampaignOption + ", Vin="
				+ Vin + ", RetailerID=" + RetailerID + ", RetailerReference=" + RetailerReference + ", TechnicianID="
				+ TechnicianID + ", ClaimType=" + ClaimType + ", Executor=" + Executor + ", MileageAtTimeOfUpdate="
				+ MileageAtTimeOfUpdate + ", UnitOfMeasure=" + UnitOfMeasure + ", DateOfChange=" + DateOfChange
				+ ", JobCardNumber=" + JobCardNumber + ", DTCCode=" + DTCCode + ", MIL=" + MIL + "]";
	}
	
}
