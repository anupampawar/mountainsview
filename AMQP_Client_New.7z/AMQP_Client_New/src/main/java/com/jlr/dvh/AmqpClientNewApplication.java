package com.jlr.dvh;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@SpringBootApplication
public class AmqpClientNewApplication {

	@Autowired
    private RabbitTemplate rabbitTemplate;
	
	public static void main(String[] args) {
		SpringApplication.run(AmqpClientNewApplication.class, args);
	}
	
	@PostConstruct
	public void AmqpClientNewApplication_1() {
		 System.out.println(">>>>** Running AMQP Client **<<<<< ");
		 CampaignStatus cs  = new CampaignStatus();
		 cs.setCampaignOrRepairID("0123456789-AP");
		 cs.setDateOfChange("20022019");
		 cs.setVin("1J4GX48S81C605935");
		 cs.setExecutor("Harman");
		 cs.setRetailerID("DeccanJLR-1");
		 
		 GsonBuilder gsonBuilder = new GsonBuilder();  
		 gsonBuilder.serializeNulls();  
		 Gson gson = gsonBuilder.create();
		 
		 List<CampaignStatus> csList  =new ArrayList<>();
		 csList.add(cs);
		 System.out.println(">>>> "+ gson.toJson(csList).toString());
		 
		 rabbitTemplate.convertAndSend(RobbitMqConfig.publishQName, gson.toJson(csList).toString());
	     System.out.println("Is listener returned ::: "+rabbitTemplate.isReturnListener());
	}

}
