package com.jlr.dvh;

import org.junit.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;

/* NOT IN USE */
public class RabbitmqTest {
	
		@Autowired
	    private RabbitTemplate rabbitTemplate;
	    
		@Test
	    public void test() throws Exception {
			///* THIS CODE  NOT IN USE */
	        rabbitTemplate.convertAndSend(RobbitMqConfig.publishQName, "RabbitMQ Spring JSON Example");
	        System.out.println("Is listener returned ::: "+rabbitTemplate.isReturnListener());
	    }
}
