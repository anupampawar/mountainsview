package com.jlr.dvh;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.stereotype.Service;

@Service
public class Consumer implements MessageListener {

	@Override
    public void onMessage(Message message) {
        String parseMessage=new String(message.getBody());
        System.out.println(">>>> Consumer message >>>>>> "+parseMessage);
    }
}
